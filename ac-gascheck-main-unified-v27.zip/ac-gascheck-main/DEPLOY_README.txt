AC GASCHECK 統一版 — 部署說明
================================
版本：v27（Cleaning 記錄與摘要雙多選修正版）

一、GitHub Pages
把本資料夾內所有 HTML、gascheck-core.js 一起上傳到 ac-gascheck 同一層目錄。
不要只更新單一 HTML，否則共用頂列、IndexedDB、Telegram 視窗會版本不一致。

二、Google Apps Script
1. 用 ac_gascheck_core_v3_fixed.gs 的全部內容取代 Apps Script 主程式。
2. 「部署」→「管理部署作業」→ 編輯現有 Web App → 選「新版本」。
3. 執行身分選「我」，存取權選「任何人」，再按部署。
4. 只有從未安裝過 AC GASCHECK 時，才執行一次 installGascheck() 並完成 Google 授權。
   已經成功執行過 installGascheck() 的現有系統，這次只需重新部署 Web App「新版本」，不用再執行安裝函式。

installGascheck() 已一次完成：
- 建立缺少的工作表
- 只補新增欄位，不清除舊資料
- 重新設定 Telegram webhook
- 清掉舊版 302 造成的 pending update 佇列
- 註冊 /gc、/menu、/status
- 建立 ActivityLog（記錄雲端上傳及 Telegram 月摘要／核可完成狀態）
- 建立每月缺件提醒觸發器
- 立即把平台選單送到群組作為測試

不需要另外執行 initSheets()、setupWebhook() 或 setExecUrl()。

三、確認 /gc
installGascheck() 回傳的 ok 必須是 true，telegram.webhook.confirmationSent 也必須是 true。
群組收到安裝測試選單後，再輸入：
  /gc
或：
  /gc@vrt_temperature_bot

若 testMenu() 能發送，但 /gc 沒回應，先執行 checkWebhook()：
- Pending 應為 0。
- LastErr 不可為 Wrong response from the webhook: 302 Found。
本版已將 Telegram update 回應改為 HtmlService 直接 200，並在 installGascheck() 一次清掉舊佇列。
若仍顯示 302，代表 Web App 還在執行舊部署；請再確認「管理部署作業」已選「新版本」。
BotFather 的 Privacy 不必再修改。

四、資料儲存
- 大量業務資料、照片索引、各模組記錄：IndexedDB
- localStorage：只保留語言、固定網址等小設定
- 舊版 localStorage 業務資料首次開啟時會自動搬到 IndexedDB，成功後才移除舊值。

五、操作方式
- 七個模組都使用同一個全寬頁首操作列：雲端上傳、雲端下載、Telegram、智慧匯入、資料匯出、中／英／柬。
- 操作列固定放在原頁首正下方，不再塞入各模組不同的標題區，因此電腦與手機位置一致。
- 手機版自動改成圖示按鈕；所有功能仍在同一列，不會跑到頁面底部。
- 雲端狀態會在操作列顯示同步中、成功、無資料或失敗；上傳與下載進行時會防止重複點擊。
- 智慧匯入集中在彈出視窗，支援拖放、多檔與自動辨識，不長期占用主畫面。
- Telegram 視窗可選：資料範圍、日／週／月／年／全部、確切期間、時段、訊息語言、群組。
- 每則 Telegram 摘要均附 Dashboard 按鈕；支援的記錄會連同照片發送。
- Temperature、EHS、Key、Water 均可輸入／匯入／上傳「檢查人」，Telegram 摘要會顯示檢查人。
- Telegram 摘要可選中文、英文或中英雙語；舊記錄沒有檢查人時顯示「—」。

六、每月 5 日上月報告檢查
- GAS 會在柬埔寨時間每月 5 日起自動檢查上個月，不需要開啟瀏覽器。
- 每個模組必須同時符合：上月資料已上傳雲端，以及上月「月摘要或核可」已發 Telegram。
- EHS 的 Recycle 與 Waste 分開檢查；Telegram 選「全部」可同時完成兩項，選單項只完成該項。
- Temperature／Cleaning 即使已發 Telegram，但未上傳雲端，仍會列為缺件。
- 缺件提醒使用中文／英文／柬文，並附 Dashboard 按鈕；同一報告月份只發一次。
- 第 5 日若 Telegram 暫時失敗，系統之後每日重試；成功後不再重複。
- 第一次升級會從安裝當月開始累積完成紀錄，並於下月 5 日首次正式檢查，避免把升級前已發送但無紀錄的舊報告誤報為缺件。
- installGascheck() 已自動建立 ActivityLog 與觸發器，不需另跑 initSheets() 或 setupMonthlyReminderTrigger()。

如需先檢查但不發送，可執行 previewMonthlyMissingReport() 查看執行記錄。
如需立即測試提醒格式，可執行 testMonthlyMissingReportReminder()；測試不會鎖定本月正式提醒。

七、v23 升級注意
- 本版介面調整只修改 gascheck-core.js；若目前已使用 v22 的 GAS v3.3-monthly-audit，不需要重新部署 GAS，也不需要再執行 installGascheck()。
- 為避免瀏覽器快取造成仍看到舊按鈕位置，建議連同全部 HTML 與 gascheck-core.js 一起更新 GitHub Pages。

八、v24 Temperature 即時天氣
- Temperature「記錄」頁會透過 GAS 讀取柬埔寨西港的 MET Norway 即時區域天氣，顯示室外溫度、室外濕度、雲量、一小時降雨、風速、天氣狀況、來源與資料時間。
- 系統只提供晴天／多雲／下雨／大雨／雷雨／酷熱／潮濕建議；必須由檢查人按「採用建議」才會帶入，不會自動覆蓋人工選擇。
- 可選「使用本機位置」提高定位準確度；若未授權或定位失敗，會自動改用西港位置。
- 選擇過去日期或即時資料已超過 30 分鐘時不可直接採用；網路中斷會標示連線失敗或上次快取資料。
- 儲存記錄時會一併保存天氣來源、座標、資料時間與確認結果，雲端同步及 Telegram 摘要都會保留即時室外天氣參考。
- GAS 會以約 20 分鐘快取代轉天氣資料，並按 MET Norway 規定保留來源標示；瀏覽器不直接連到外部天氣服務。
- 本次沒有修改任何工作表欄位或建立新 Sheet，因此不需要 initSheets()；但新增 weatherCurrent 後端入口，必須用 ac_gascheck_core_v3_fixed.gs 重新部署 Web App 新版本。重新部署後不需要再執行 installGascheck()。

九、v25 EHS Recycle／Waste
- Recycle、Waste、Report 的期間固定依「日／週／月／年」排列，並有前後期間按鈕。
- Recycle 月／週／日會列出每筆收料；年度會先列 12 個月份，按「查看明細」可進入該月記錄。
- Waste 日／週／月／年都會直接列出每筆收料，不再只顯示圖表。
- 所有重量匯入後統一存成數字 kg；Excel 的 500kg、2,000 kg 或純數字都會轉成公斤，畫面及匯出一律顯示 kg。
- Recycle Excel 內嵌照片會依日期列匯入，列表可點照片數量預覽；雲端網址照片也可由 Telegram 發送。
- Report 卡片與比較表會同時顯示當期、上期與增減，分開呈現 Recycle kg／筆數、Waste kg／筆數與照片數。
- Recycle 與 Waste 都可新增、編輯、刪除、儲存、期間 Excel 匯出；共用頂列提供雲端上傳／下載、Telegram 與智慧匯入。
- 智慧匯入會掃描所有有效工作表並排除車輛清單等無關分頁。若 Excel 年度總表與每日明細不一致，會提示差異並採用有日期／照片可追溯的每日明細。
- 本版修正 EHS 工作表表頭並支援 Telegram 網址照片，所以必須用新的 ac_gascheck_core_v3_fixed.gs 重新部署 Web App「新版本」。
- 不建立新的工作表；缺少欄位會在第一次雲端寫入時自動補上，因此不用執行 initSheets()、installGascheck() 或 setupWebhook()。

十、v26 Cleaning Telegram
- Telegram 視窗的地點與清潔時段改為籤選，可同時選多個地點及多個實際時段，再按一次「發送」完成。
- 時段直接使用 Cleaning 設定內的 07:30、08:30…等實際時段，不再只能選籠統的早上／下午。
- 摘要內每筆記錄改用與「新增記錄 → Telegram」相同格式：日期、地點、清潔員、檢查員、實際時間、六個清潔項目圖示、通過／異常、備註及照片數。
- 摘要附帶所選記錄的照片（最多 5 張）及 Dashboard 按鈕；原始 ISO 日期會轉成 yyyy-mm-dd，不再顯示 T00:00:00.000Z。
- 本次只修改 Cleaning HTML 與 gascheck-core.js，沒有新增 Sheet、修改工作表欄位或修改 GAS。若已部署 v25 的 GAS，不必重新部署 GAS；只要更新全部 HTML 與 gascheck-core.js，並重新整理瀏覽器快取。
- 不需要執行 initSheets()、installGascheck()、setupWebhook()。

十一、v27 Cleaning 記錄與摘要雙多選
- 「新增記錄」的地點改成和清潔時段相同的籤選按鈕，可同時選多個地點及多個時段。
- 按一次「儲存記錄」會依所選地點建立多筆記錄，所有記錄共用本次日期、時段、清潔員、檢查員、巡查結果、備註與照片，並以同一批次上傳。
- 按一次「Telegram」會把本次所選的全部地點合併成一則完整清潔訊息，每個地點均顯示實際時間與六項清潔圖示，並附照片和 Dashboard。
- 頂列 Telegram 摘要的地點及時段也都是多選籤；可多選地點、多選 07:30／08:30…實際時段，再選日／週／月／年及期間發送。
- Cleaning 載入共用核心時加入 v27 版本參數，避免手機仍使用舊快取而顯示 loc_factory 內部代碼或單選下拉。
- 畫面左上版本為 v2.2；若仍看到 v2.1，代表 GitHub Pages 或手機仍是舊檔。
- 本次只修改 Cleaning HTML 與 gascheck-core.js；不需更新 GAS，也不需執行 initSheets()、installGascheck() 或 setupWebhook()。
