/* ═══════════════════════════════════════════════════════════════
   AC_GASCHECK_CORE  GAS v3.5-ehs-records
   ─────────────────────────────────────────────────────────────
   v3.0 重大修正：
   ★ writeRecords_ 不再「刪光全部再寫入」→ 改為 ID 合併
     （舊版任何裝置推 3 筆，Sheet 上 50 筆會全部消失）
   ★ 合併規則：ID 聯集，updatedAt 新者勝，Sheet 既有資料永不無故消失
   ★ push 支援 mode:'merge'（預設）/ 'replace'（明確指定才整包取代）
   ★ 欄位自動擴充：新欄位出現時自動補到表頭，不丟資料
   ★ BASE_URL 指向 v2 檔案
═══════════════════════════════════════════════════════════════ */

const CFG = {
  CORE_VERSION : 'v3.5-ehs-records',
  SHEET_ID  : '16AhYV8aEKQWLIm-5dotUQX1bN_n7Rilncf1A7XRKHlk',
  BOT_TOKEN : '8673221735:AAH0KoC89DPLNu4D70inRfkY2xwedLkXjnw',
  CHAT_ID   : '-5113064563',
  // 固定 Web App 入口：setupWebhook() 不再要求先手動 setExecUrl()
  EXEC_URL  : 'https://script.google.com/macros/s/AKfycbzRsf_DuYJu0kXxqefR8qbLWhO7uz2flCY7jkPQQ73ZMwptcHDwrtJnhBQFwxG_EM3v/exec',
  TZ        : 'Asia/Phnom_Penh',
  BASE_URL  : 'https://saintdou-weng.github.io/ac-gascheck/',
  MODULES   : ['asset','dormitory','cleaning','keymovement','ehs','waterdrum','temperature'],
  ID_FIELD  : 'id',
  TS_FIELD  : 'updatedAt',
  DRIVE_FOLDER : 'AC_GASCHECK_Photos',   // 照片存放的 Drive 資料夾（自動建立）
  PHOTO_FIELD  : 'photos',               // 記錄中存放照片的欄位名
};

const TG_API = () => `https://api.telegram.org/bot${CFG.BOT_TOKEN}`;

// ═══════════════════════════════════════════════════════════════
// doPost — Telegram webhook update  vs  GASCHECK data push
// ═══════════════════════════════════════════════════════════════
function doPost(e) {
  let isTelegramUpdate = false;
  try {
    const body = parseBody_(e);
    isTelegramUpdate = body.update_id !== undefined;
    Logger.log('[doPost] update_id=' + (body.update_id||'—') + ' action=' + (body.action||'—'));

    // ── TYPE A: Telegram Webhook Update ──
    if (body.update_id !== undefined) {
      const props = PropertiesService.getScriptProperties();
      const uid   = parseInt(body.update_id, 10);
      const done  = (props.getProperty('tg_processed_uids') || '').split(',').filter(Boolean);
      if (done.includes(String(uid))) {
        Logger.log('[TG] dup skip uid=' + uid);
        return telegramResp_({ ok: true, skipped: true });
      }
      try {
        // 只有處理成功後才記錄 update_id；若 Telegram/GAS 暫時失敗，重送時仍可再處理。
        handleTelegram(body);
        done.push(String(uid));
        if (done.length > 50) done.splice(0, done.length - 50);
        props.setProperty('tg_processed_uids', done.join(','));
        return telegramResp_({ ok: true, uid: uid });
      } catch(err) {
        Logger.log('[TG] err uid=' + uid + ': ' + err);
        return telegramResp_({ ok: false, retryable: true, uid: uid, error: String(err) });
      }
    }

    // ── TYPE B: GASCHECK API ──
    const action = body.action || body.type || '';
    Logger.log('[doPost] action=' + action);

    switch (action) {
      case 'push':
      case 'save':         return okResp(handlePush_(body));
      case 'tempSync':
      case 'tempImport':   return okResp(handlePush_(Object.assign({}, body, {tool:'temperature',records:body.records||[],zones:body.zones||[],zonesMode:body.zonesMode||'merge'})));
      case 'tempDelete':
      case 'delete':       return okResp(handleDelete_(body.tool, body.id));
      case 'cleaningSave': return okResp(handlePush_(Object.assign({}, body, {tool:'cleaning',records:body.data?[body.data]:[]})));
      case 'cleaningUpload': return okResp(handlePush_(Object.assign({}, body, {tool:'cleaning',records:body.records||[]})));
      case 'cleaningDownload': return okResp(handlePull_('cleaning'));
      case 'pull':         return okResp(handlePull_(body.tool));
      case 'uploadPhoto':  return okResp(handleUploadPhoto_(body));
      case 'weatherCurrent': return okResp(handleWeatherCurrent_(body));
      case 'status':       return okResp(handleStatus_());
      case 'clearCache':   clearUidCache(); return okResp({ cleared:true });
      case 'notify':
      case 'telegram':
      case 'telegramMenu': return okResp(handleTelegramSend_(body));
      case 'ping':         return okResp({ pong: true });
      default:
        Logger.log('[doPost] unknown action: "' + action + '"');
        return okResp({ ok: false, error: 'Unknown action: ' + action });
    }
  } catch(err) {
    Logger.log('[doPost ERROR] ' + err);
    return isTelegramUpdate
      ? telegramResp_({ ok:false, error:err.toString() })
      : failResp(err.toString());
  }
}

// ─── Body Parser: JSON / text-plain / URLEncoded ───
function parseBody_(e) {
  try {
    const raw    = (e.postData && e.postData.contents) ? e.postData.contents.trim() : '';
    const params = e.parameter || {};

    if (raw && raw.charAt(0) === '{') {
      try { return JSON.parse(raw); } catch(err) {}
    }
    if (params.payload) {
      try { return JSON.parse(params.payload); } catch(err) {}
    }
    if (raw) {
      const m = raw.match(/(?:^|&)payload=([^&]+)/);
      if (m) {
        try { return JSON.parse(decodeURIComponent(m[1].replace(/\+/g, ' '))); } catch(err) {}
      }
    }
    return params;
  } catch(outer) {
    Logger.log('[parse ERR] ' + outer);
    return {};
  }
}

// ═══════════════════════════════════════════════════════════════
// doGet
// ═══════════════════════════════════════════════════════════════
function doGet(e) {
  try {
    const p      = (e && e.parameter) ? e.parameter : {};
    const action = p.action || p.type || (p.ping ? 'ping' : 'status');
    switch (action) {
      case 'status': return okResp(handleStatus_());
      case 'pull':   return okResp(handlePull_(p.tool));
      case 'tempList': return okResp(handlePull_('temperature'));
      case 'ping':   return okResp({ pong: true, ts: nowStr_() });
      default:       return okResp({ message: 'AC_GASCHECK_CORE ' + CFG.CORE_VERSION, ts: nowStr_() });
    }
  } catch(err) {
    return failResp(err.toString());
  }
}

// ═══════════════════════════════════════════════════════════════
// ★★★ DATA HANDLERS — 安全合併版 ★★★
// ═══════════════════════════════════════════════════════════════

function handleStatus_() {
  const ss   = SpreadsheetApp.openById(CFG.SHEET_ID);
  const mods = {};
  CFG.MODULES.forEach(function(mod) {
    try {
      const sh = ss.getSheetByName(mod);
      mods[mod] = sh ? Math.max(0, sh.getLastRow() - 1) : 0;
    } catch(e) { mods[mod] = 0; }
  });
  return { ok: true, version:CFG.CORE_VERSION, modules: mods, ts: nowStr_() };
}

/**
 * 西港／裝置位置的目前區域天氣。
 * 由 GAS 代轉 MET Norway Locationforecast，避免瀏覽器 CORS／識別問題；
 * CacheService 減少重複請求，同一座標約 20 分鐘更新一次。
 * MET Norway 開放資料可商業使用，但顯示時必須保留來源標示。
 */
function handleWeatherCurrent_(payload) {
  payload = payload || {};
  let lat = Number(payload.latitude), lon = Number(payload.longitude);
  if (!isFinite(lat) || !isFinite(lon)) { lat = 10.625; lon = 103.523; }
  if (lat < -90 || lat > 90 || lon < -180 || lon > 180) throw new Error('Invalid weather coordinates');

  const cache = CacheService.getScriptCache();
  const cacheKey = 'gcwx_' + lat.toFixed(3) + '_' + lon.toFixed(3);
  const cached = cache.get(cacheKey);
  if (cached) {
    try {
      const out = JSON.parse(cached); out.serverCached = true; return out;
    } catch (ignore) {}
  }

  const api = 'https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=' + encodeURIComponent(lat.toFixed(5)) + '&lon=' + encodeURIComponent(lon.toFixed(5));
  const response = UrlFetchApp.fetch(api, {
    method: 'get',
    headers: { 'User-Agent': 'AC-GASCHECK/3.4 https://saintdou-weng.github.io/ac-gascheck/' },
    muteHttpExceptions: true,
    followRedirects: true
  });
  const status = response.getResponseCode();
  if (status !== 200) throw new Error('MET Norway HTTP ' + status);
  const json = JSON.parse(response.getContentText());
  const series = json && json.properties && json.properties.timeseries;
  if (!Array.isArray(series) || !series.length) throw new Error('MET Norway returned no weather data');
  const first = series[0], data = first.data || {}, details = (data.instant && data.instant.details) || {};
  const next = data.next_1_hours || data.next_6_hours || data.next_12_hours || {};
  const nextDetails = next.details || {}, summary = next.summary || {};
  const out = {
    ok: true,
    source: 'MET Norway',
    sourceUrl: 'https://api.met.no/weatherapi/locationforecast/2.0/documentation',
    latitude: lat,
    longitude: lon,
    timezone: CFG.TZ,
    observedAt: first.time || '',
    fetchedAt: new Date().toISOString(),
    temperature: Number(details.air_temperature),
    humidity: Number(details.relative_humidity),
    precipitation: Number(nextDetails.precipitation_amount) || 0,
    cloudCover: Number(details.cloud_area_fraction),
    windSpeed: Number(details.wind_speed),
    windDirection: Number(details.wind_from_direction),
    weatherCode: String(summary.symbol_code || ''),
    serverCached: false
  };
  if (!isFinite(out.temperature) || !isFinite(out.humidity)) throw new Error('MET Norway weather fields missing');
  cache.put(cacheKey, JSON.stringify(out), 1200);
  return out;
}

/**
 * handlePush_
 * mode:'merge'（預設）— ID 聯集，updatedAt 新者勝，Sheet 既有資料保留
 * mode:'replace'      — 明確要求才整包取代（危險，需前端明示）
 */
function handlePush_(payload) {
  const tool    = payload.tool;
  const records = payload.records || payload.list;   // 相容兩種欄位名
  const mode    = payload.mode === 'replace' ? 'replace' : 'merge';

  if (!tool)                         throw new Error('Missing tool');
  if (!records)                      throw new Error('Missing records');
  if (CFG.MODULES.indexOf(tool) < 0) throw new Error('Unknown module: ' + tool);
  if (!Array.isArray(records))       throw new Error('records must be Array');

  // 區域是溫度模組的設定資料，不放在每一筆讀值內；以 union 保存，只有明確 replace 才刪除雲端既有區域。
  if (tool === 'temperature' && Array.isArray(payload.zones)) {
    saveTemperatureZones_(payload.zones, payload.zonesMode || 'merge');
  }

  // ★ 照片處理：把記錄裡的 base64 存進 Drive，只留連結（避免 Sheet 儲存格 5 萬字元上限）
  const photoStat = offloadPhotosToDrive_(tool, records);

  const sheet  = getOrCreateSheet_(tool);
  const before = Math.max(0, sheet.getLastRow() - 1);

  const stat = (mode === 'replace')
    ? replaceRecords_(sheet, records)
    : mergeRecords_(sheet, records);

  writeLog_(mode, tool, records.length);
  recordCloudUploadActivity_(payload, tool, records);

  try {
    tgSendText_(CFG.CHAT_ID,
      '☁️ <b>AC GASCHECK · ' + (mode === 'merge' ? 'Merge' : 'Replace') + '</b>\n' +
      '📦 ' + tool + '\n' +
      '📥 收到 ' + records.length + ' 筆\n' +
      '➕ 新增 ' + stat.added + ' ｜ 🔄 更新 ' + stat.updated + ' ｜ 🛡 保留 ' + stat.kept + '\n' +
      (photoStat.uploaded ? '📷 照片上傳 ' + photoStat.uploaded + ' 張 → Drive\n' : '') +
      '📊 ' + before + ' → ' + stat.total + ' 筆\n' +
      '⏰ ' + Utilities.formatDate(new Date(), CFG.TZ, 'MM/dd HH:mm')
    );
  } catch(e) {}

  const out = { ok: true, tool: tool, mode: mode,
           received: records.length, before: before,
           added: stat.added, updated: stat.updated, kept: stat.kept,
           photosUploaded: photoStat.uploaded,
           count: stat.total, ts: nowStr_() };
  if (tool === 'temperature') out.zones = getTemperatureZones_();
  return out;
}

// ═══════════════════════════════════════════════════════════════
// ★ 照片轉存 Google Drive（Sheet 只留連結）
// ═══════════════════════════════════════════════════════════════

/** 取得（或建立）照片資料夾 */
function getPhotoFolder_() {
  const it = DriveApp.getFoldersByName(CFG.DRIVE_FOLDER);
  if (it.hasNext()) return it.next();
  const folder = DriveApp.createFolder(CFG.DRIVE_FOLDER);
  Logger.log('[Drive] 建立資料夾: ' + CFG.DRIVE_FOLDER);
  return folder;
}

/** 把單張 base64 dataURL 存到 Drive，回傳可檢視連結 */
function savePhotoToDrive_(dataUrl, tool, recId, idx) {
  try {
    const m = String(dataUrl).match(/^data:(image\/\w+);base64,(.+)$/);
    if (!m) return dataUrl;                         // 已是連結或非 base64，原樣返回
    const mime = m[1], b64 = m[2];
    const ext  = mime.split('/')[1] || 'jpg';
    const bytes = Utilities.base64Decode(b64);
    const stamp = Utilities.formatDate(new Date(), CFG.TZ, 'yyyyMMdd_HHmmss');
    const name  = tool + '_' + (recId || 'r') + '_' + (idx + 1) + '_' + stamp + '.' + ext;
    const blob  = Utilities.newBlob(bytes, mime, name);
    const file  = getPhotoFolder_().createFile(blob);
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    // 直接可用於 <img> 的連結格式
    return 'https://drive.google.com/uc?export=view&id=' + file.getId();
  } catch (err) {
    Logger.log('[Drive] savePhoto error: ' + err);
    return '';                                      // 失敗回空，不阻擋整批
  }
}

/**
 * 掃描整批記錄，把 photos 陣列裡的 base64 換成 Drive 連結
 * 直接就地修改 records（傳參考），供後續寫入 Sheet
 */
function offloadPhotosToDrive_(tool, records) {
  const F = CFG.PHOTO_FIELD;
  let uploaded = 0;
  (records || []).forEach(function (rec) {
    if (!rec || !Array.isArray(rec[F]) || !rec[F].length) return;
    rec[F] = rec[F].map(function (p, i) {
      if (typeof p === 'string' && p.indexOf('data:image') === 0) {
        const link = savePhotoToDrive_(p, tool, rec[CFG.ID_FIELD], i);
        if (link) uploaded++;
        return link;
      }
      return p;                                     // 已是連結 → 不動
    }).filter(Boolean);
  });
  if (uploaded) Logger.log('[Drive] 本批上傳 ' + uploaded + ' 張照片');
  return { uploaded: uploaded };
}

/** 前端即時上傳單張照片用（可選，讓存檔前就先傳好） */
function handleUploadPhoto_(payload) {
  const link = savePhotoToDrive_(payload.dataUrl, payload.tool || 'misc',
                                 payload.recId || 'r', payload.idx || 0);
  return { ok: !!link, url: link };
}

function handlePull_(tool) {
  if (!tool || CFG.MODULES.indexOf(tool) < 0) throw new Error('Unknown module: ' + (tool||'?'));
  const sheet   = getOrCreateSheet_(tool);
  const records = sheetToJson_(sheet);
  // 同時提供 records 與 list 兩種欄位名，相容新舊前端
  const out = { ok: true, tool: tool, records: records, list: records,
           data: { list: records }, count: records.length, ts: nowStr_() };
  if (tool === 'temperature') out.zones = getTemperatureZones_();
  return out;
}

function handleDelete_(tool, id) {
  if (!tool || CFG.MODULES.indexOf(tool) < 0) throw new Error('Unknown module: ' + (tool || '?'));
  if (id === undefined || id === null || String(id) === '') throw new Error('Missing id');
  const sheet = getOrCreateSheet_(tool);
  const oldHeaders = sheet.getLastColumn() > 0 ? sheet.getRange(1,1,1,sheet.getLastColumn()).getValues()[0].map(String) : [CFG.ID_FIELD];
  const before = sheetToJson_(sheet);
  const kept = before.filter(function(r){ return String(r[CFG.ID_FIELD] || '') !== String(id); });
  if (kept.length) replaceRecords_(sheet, kept);
  else {
    sheet.clear();
    sheet.getRange(1,1,1,oldHeaders.length).setValues([oldHeaders]).setBackground('#1A3458').setFontColor('#fff').setFontWeight('bold');
    sheet.setFrozenRows(1);
  }
  return {ok:true,tool:tool,id:String(id),deleted:before.length-kept.length,count:kept.length,ts:nowStr_()};
}

function getTemperatureZones_() {
  try { return JSON.parse(PropertiesService.getScriptProperties().getProperty('GASCHECK_TEMPERATURE_ZONES') || '[]'); }
  catch(e) { return []; }
}
function saveTemperatureZones_(incoming, mode) {
  if (mode === 'replace') {
    PropertiesService.getScriptProperties().setProperty('GASCHECK_TEMPERATURE_ZONES', JSON.stringify(incoming || []));
    return incoming || [];
  }
  const local = getTemperatureZones_(), map = {}, order = [];
  (local || []).forEach(function(z){ if (!z || !z.id) return; map[String(z.id)] = z; order.push(String(z.id)); });
  (incoming || []).forEach(function(z){
    if (!z || !z.id) return;
    const k=String(z.id), old=map[k];
    if (!old) { map[k]=z; order.push(k); return; }
    const ot=String(old.updatedAt||''), nt=String(z.updatedAt||'');
    if (!ot || (nt && nt > ot)) map[k]=Object.assign({}, old, z);
  });
  const merged=order.map(function(k){return map[k];});
  PropertiesService.getScriptProperties().setProperty('GASCHECK_TEMPERATURE_ZONES', JSON.stringify(merged));
  return merged;
}

// ═══════════════════════════════════════════════════════════════
// ★ 核心：合併寫入（絕不無故刪除既有資料）
// ═══════════════════════════════════════════════════════════════
function mergeRecords_(sheet, incoming) {
  const stat = { added: 0, updated: 0, kept: 0, total: 0 };
  if (!incoming || !incoming.length) {
    stat.total = Math.max(0, sheet.getLastRow() - 1);
    stat.kept  = stat.total;
    return stat;
  }

  const ID = CFG.ID_FIELD, TS = CFG.TS_FIELD;
  const existing = sheetToJson_(sheet);

  // 1. 表頭聯集（新欄位自動擴充，舊欄位保留）
  const headers = [];
  const seen    = {};
  function addH(h) { h = String(h).trim(); if (h && !seen[h]) { seen[h] = 1; headers.push(h); } }
  if (existing.length) Object.keys(existing[0]).forEach(addH);
  else if (sheet.getLastRow() >= 1 && sheet.getLastColumn() >= 1) {
    sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].forEach(addH);
  }
  incoming.forEach(function(r) { Object.keys(r || {}).forEach(addH); });
  if (!seen[ID]) headers.unshift(ID);

  // 2. 以 ID 建索引（既有資料先入，代表本地優先權）
  const map   = {};
  const order = [];
  existing.forEach(function(r) {
    const k = (r && r[ID] != null && String(r[ID]) !== '') ? String(r[ID]) : ('_row' + order.length);
    if (!map[k]) order.push(k);
    map[k] = r;
  });

  // 3. 合入新資料
  incoming.forEach(function(r) {
    if (!r) return;
    const k = (r[ID] != null && String(r[ID]) !== '') ? String(r[ID]) : ('_new' + order.length + '_' + Math.random().toString(36).slice(2,7));
    if (!map[k]) { map[k] = r; order.push(k); stat.added++; return; }
    const tOld = map[k][TS] ? String(map[k][TS]) : '';
    const tNew = r[TS]      ? String(r[TS])      : '';
    if (tNew && (!tOld || tNew > tOld)) {
      // 新者勝，但欄位用「補齊」而非覆蓋整列 → 舊欄位不會被清空
      map[k] = Object.assign({}, map[k], r);
      stat.updated++;
    } else {
      // 平手或無時間戳 → 保留既有；僅補上既有缺少的欄位
      const merged = Object.assign({}, r, map[k]);
      map[k] = merged;
      stat.kept++;
    }
  });

  // 4. 一次性寫回
  const rows = order.map(function(k) {
    const rec = map[k] || {};
    return headers.map(function(h) {
      const v = rec[h];
      if (v === undefined || v === null) return '';
      if (typeof v === 'object')         return JSON.stringify(v);
      return v;
    });
  });

  sheet.clear();
  sheet.getRange(1, 1, 1, headers.length).setValues([headers])
       .setBackground('#1A3458').setFontColor('#fff').setFontWeight('bold');
  sheet.setFrozenRows(1);
  if (rows.length) sheet.getRange(2, 1, rows.length, headers.length).setValues(rows);

  stat.total = rows.length;
  Logger.log('[merge] +' + stat.added + ' ~' + stat.updated + ' =' + stat.kept + ' → ' + stat.total);
  return stat;
}

/** 整包取代 — 只有前端明確傳 mode:'replace' 才會執行 */
function replaceRecords_(sheet, records) {
  const stat = { added: records.length, updated: 0, kept: 0, total: records.length };
  const headers = records.length ? Object.keys(records[0]) : [CFG.ID_FIELD];
  const rows = records.map(function(rec) {
    return headers.map(function(h) {
      const v = rec[h];
      if (v === undefined || v === null) return '';
      if (typeof v === 'object')         return JSON.stringify(v);
      return v;
    });
  });
  sheet.clear();
  sheet.getRange(1, 1, 1, headers.length).setValues([headers])
       .setBackground('#8B1A1A').setFontColor('#fff').setFontWeight('bold');
  sheet.setFrozenRows(1);
  if (rows.length) sheet.getRange(2, 1, rows.length, headers.length).setValues(rows);
  Logger.log('[replace] ' + rows.length + ' 筆（整包取代）');
  return stat;
}

function sheetToJson_(sheet) {
  const data = sheet.getDataRange().getValues();
  if (data.length < 2) return [];
  const headers = data[0].map(function(h) { return String(h).trim(); });
  const out = [];
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    if (row.every(function(c) { return c === '' || c === null; })) continue;
    const obj = {};
    headers.forEach(function(h, j) { if (h) obj[h] = row[j] !== undefined ? row[j] : ''; });
    out.push(obj);
  }
  return out;
}

// ═══════════════════════════════════════════════════════════════
// TELEGRAM
// ═══════════════════════════════════════════════════════════════
function handleTelegram(update) {
  if (update.callback_query) {
    const cq     = update.callback_query;
    const data   = cq.data || '';
    const chatId = String(cq.message.chat.id);
    answerCallbackQuery_(cq.id);
    if      (data === 'gc_status' && !sendStatusMessage_(chatId)) throw new Error('Telegram status send failed');
    else if (data === 'gc_menu' && !sendTelegramMenu(chatId))     throw new Error('Telegram menu send failed');
    return;
  }
  if (update.message) {
    const msg    = update.message;
    const chatId = String(msg.chat.id);
    // Telegram 群組可能送出 /gc 或 /gc@BotName；caption 也一併支援，避免不同訊息型態漏接。
    const text   = String(msg.text || msg.caption || '').trim();
    const m      = text.match(/^\/([A-Za-z0-9_]+)(?:@[A-Za-z0-9_]+)?(?:\s|$)/);
    const cmd    = m ? '/' + m[1].toLowerCase() : text.split(/\s+/)[0].split('@')[0].toLowerCase();
    const MENU   = ['/gc','/gascheck','/start','/menu','/platform','/help'];
    if (MENU.includes(cmd)) {
      if (!sendTelegramMenu(chatId)) throw new Error('Telegram /gc menu send failed for chat ' + chatId);
      return;
    }
    if (cmd === '/status') {
      if (!sendStatusMessage_(chatId)) throw new Error('Telegram /status send failed for chat ' + chatId);
      return;
    }
    if (cmd.charAt(0) === '/') {
      if (!sendTelegramMenu(chatId)) throw new Error('Telegram command fallback send failed for chat ' + chatId);
      return;
    }
  }
}

function sendTelegramMenu(chatId) {
  if (!chatId) chatId = CFG.CHAT_ID;
  const B  = CFG.BASE_URL;
  const ts = Utilities.formatDate(new Date(), CFG.TZ, 'MM/dd HH:mm');
  const text = [
    '♻️ <b>AC GASCHECK 平台</b> — ' + ts,
    '━━━━━━━━━━━━━━━━',
    '選擇要開啟的模組 / Select Module:',
  ].join('\n');

  const keyboard = { inline_keyboard: [
    [{ text:'📦 Asset',  url:B+'ac_gascheck_asset_v2.html'      },
     { text:'🏠 Dorm',   url:B+'ac_gascheck_dormitory_v2.html'  }],
    [{ text:'🧹 Cleaning', url:B+'ac_gascheck_cleaning_v2.html' },
     { text:'🔑 Key',    url:B+'ac_gascheck_keymovement_v2.html'}],
    [{ text:'♻️ EHS',    url:B+'ac_gascheck_ehs_v2.html'        },
     { text:'💧 Water',  url:B+'ac_gascheck_waterdrum_v2.html'  }],
    [{ text:'🌡️ Temp',   url:B+'ac_gascheck_temperature_v2.html'},
     { text:'🏠 Portal', url:B+'ac_gascheck_portal_v1.html'     }],
    [{ text:'☁️ Cloud Status', callback_data:'gc_status' }],
  ]};

  const ok = tgSendWithKeyboard_(chatId, text, keyboard);
  if (!ok) tgSendText_(chatId, '♻️ AC GASCHECK Platform\n' + B + 'ac_gascheck_portal_v1.html');
  return ok;
}

function sendStatusMessage_(chatId) {
  if (!chatId) chatId = CFG.CHAT_ID;
  const s     = handleStatus_();
  const icons = { asset:'📦',dormitory:'🏠',cleaning:'🧹',keymovement:'🔑',ehs:'♻️',waterdrum:'💧',temperature:'🌡️' };
  const lines = ['☁️ <b>AC GASCHECK 雲端狀態</b>','━━━━━━━━━━━━━━━━'];
  Object.keys(s.modules).forEach(function(m) {
    lines.push((icons[m]||'📋') + ' ' + m + ': ' + s.modules[m] + ' 筆');
  });
  lines.push('━━━━━━━━━━━━━━━━','⏰ ' + Utilities.formatDate(new Date(), CFG.TZ, 'yyyy/MM/dd HH:mm'));
  return tgSendText_(chatId, lines.join('\n'));
}

function sendTelegramMessage(chatId, text, keyboard, photos, tool) {
  if (!chatId) chatId = CFG.CHAT_ID;
  if (!text) return { ok: false, error: 'No text' };
  let kb = null;
  if (keyboard && Array.isArray(keyboard) && keyboard.length) {
    kb = { inline_keyboard: keyboard.map(function(row) {
      return row.map(function(btn) {
        const b = { text: btn.text };
        if (btn.url)  b.url = btn.url;
        if (btn.data) b.callback_data = btn.data;
        return b;
      });
    })};
  } else if (keyboard && keyboard.inline_keyboard) kb = keyboard;
  const ok = kb ? tgSendWithKeyboard_(chatId, text, kb) : tgSendText_(chatId, text);
  if (ok && Array.isArray(photos)) {
    const captions = {
      asset:'Asset', dormitory:'Dormitory', cleaning:'Cleaning Record',
      keymovement:'Key Movement', ehs:'Recycle / Waste',
      waterdrum:'Drinking Water', temperature:'Temperature & Humidity'
    };
    const caption = 'AC GASCHECK · ' + (captions[String(tool || '')] || 'Record');
    photos.slice(0, 5).forEach(function(photo) {
      if (typeof photo === 'string' && (photo.indexOf('data:image/') === 0 || /^https?:\/\//i.test(photo))) tgSendPhoto_(chatId, photo, caption);
    });
  }
  return { ok: ok };
}

/**
 * 前端 Telegram 統一入口。訊息成功送出後，同步留下報告月份、期間與訊息類型，
 * 供每月 5 日的缺件檢查使用；一般測試訊息沒有 reportMonth 時不會誤算完成。
 */
function handleTelegramSend_(body) {
  body = body || {};
  const result = sendTelegramMessage(
    body.chatId || CFG.CHAT_ID,
    body.text,
    body.buttons,
    body.photos,
    body.tool
  );
  if (result && result.ok) {
    const month = normalizeMonthKey_(body.reportMonth || body.reportRef || '');
    if (month && CFG.MODULES.indexOf(String(body.tool || '')) >= 0) {
      writeActivity_({
        event:'telegram', tool:String(body.tool), reportMonth:month,
        period:String(body.reportPeriod || ''),
        mode:normalizeReportMode_(body.reportMode, body.text),
        scope:String(body.reportScope || ''), slot:String(body.reportSlot || ''),
        language:String(body.reportLanguage || ''), ref:String(body.reportRef || ''),
        count:1, note:'frontend'
      });
    }
  }
  return result;
}

function tgSendText_(chatId, text) {
  try {
    const r = UrlFetchApp.fetch(TG_API() + '/sendMessage', {
      method:'post', contentType:'application/json', muteHttpExceptions:true,
      payload: JSON.stringify({ chat_id: chatId, text: text, parse_mode: 'HTML' }),
    });
    return JSON.parse(r.getContentText()).ok === true;
  } catch(err) { Logger.log('[tgSendText ERR] ' + err); return false; }
}

function tgSendWithKeyboard_(chatId, text, keyboard) {
  try {
    const r = UrlFetchApp.fetch(TG_API() + '/sendMessage', {
      method:'post', contentType:'application/json', muteHttpExceptions:true,
      payload: JSON.stringify({ chat_id:chatId, text:text, parse_mode:'HTML', reply_markup:keyboard }),
    });
    const d = JSON.parse(r.getContentText());
    if (!d.ok) Logger.log('[tgKb] fail: ' + d.description);
    return d.ok === true;
  } catch(err) { Logger.log('[tgKb ERR] ' + err); return false; }
}

function answerCallbackQuery_(queryId) {
  try {
    UrlFetchApp.fetch(TG_API() + '/answerCallbackQuery', {
      method:'post', contentType:'application/json', muteHttpExceptions:true,
      payload: JSON.stringify({ callback_query_id: queryId }),
    });
  } catch(e) {}
}

// ═══════════════════════════════════════════════════════════════
// WEBHOOK
// ═══════════════════════════════════════════════════════════════
/** 取得目前 Apps Script 正式 /exec 網址；重部署後優先使用最新部署。 */
function currentExecUrl_() {
  try {
    const u = String(ScriptApp.getService().getUrl() || '').trim();
    if (u.indexOf('/exec') >= 0) return u;
  } catch (e) {
    Logger.log('[currentExecUrl] ' + e);
  }
  return '';
}

function tgSendPhoto_(chatId, dataUrl, caption) {
  try {
    if (/^https?:\/\//i.test(String(dataUrl || ''))) {
      const remote = UrlFetchApp.fetch(TG_API() + '/sendPhoto', {
        method:'post', contentType:'application/json', muteHttpExceptions:true,
        payload:JSON.stringify({chat_id:String(chatId),photo:String(dataUrl),caption:String(caption || '').slice(0,1024),parse_mode:'HTML'})
      });
      const parsed = JSON.parse(remote.getContentText());
      if (!parsed.ok) Logger.log('[tgPhoto URL] fail: ' + parsed.description);
      return parsed.ok === true;
    }
    const m = String(dataUrl).match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.*)$/);
    if (!m) return false;
    const bytes = Utilities.base64Decode(m[2]);
    const ext = (m[1].split('/')[1] || 'jpeg').replace(/[^a-z0-9]/gi, '') || 'jpeg';
    const blob = Utilities.newBlob(bytes, m[1], 'ehs.' + ext);
    const r = UrlFetchApp.fetch(TG_API() + '/sendPhoto', {
      method:'post', muteHttpExceptions:true,
      payload:{chat_id:String(chatId), photo:blob, caption:String(caption || '').slice(0, 1024), parse_mode:'HTML'}
    });
    const d = JSON.parse(r.getContentText());
    if (!d.ok) Logger.log('[tgPhoto] fail: ' + d.description);
    return d.ok === true;
  } catch(err) { Logger.log('[tgSendPhoto ERR] ' + err); return false; }
}

function setExecUrl(url) {
  if (!url || url.indexOf('script.google.com') < 0) { Logger.log('ERROR: 無效 URL'); return; }
  PropertiesService.getScriptProperties().setProperty('GASCHECK_EXEC_URL', url);
  Logger.log('✅ EXEC URL 已儲存: ' + url + '\n現在執行 setupWebhook()');
}

function setupWebhook(dropPending) {
  const props = PropertiesService.getScriptProperties();
  // 由專案設定提供固定入口；只有未設定時才退回舊的 Script Properties。
  // 這樣重部署後執行 setupWebhook() 不會再出現「請先 setExecUrl」錯誤。
  const detectedUrl = currentExecUrl_();
  let execUrl = detectedUrl || CFG.EXEC_URL || props.getProperty('GASCHECK_EXEC_URL') || '';
  if (execUrl) props.setProperty('GASCHECK_EXEC_URL', execUrl);
  if (!execUrl || execUrl.indexOf('/exec') < 0) {
    const msg = 'ERROR: CFG.EXEC_URL 尚未設定有效的 /exec URL';
    Logger.log(msg); return { ok:false, error:msg };
  }
  try {
    clearUidCache();
    const r = UrlFetchApp.fetch(TG_API() + '/setWebhook', {
      method:'post', contentType:'application/json', muteHttpExceptions:true,
      payload: JSON.stringify({
        url:execUrl,
        allowed_updates:['message','callback_query'],
        // install/repair 時清掉舊版 302 造成的堵塞佇列；單獨執行 setupWebhook() 則保留現有更新。
        drop_pending_updates:dropPending === true,
        max_connections:20
      }),
    });
    const d = JSON.parse(r.getContentText());
    Logger.log('[setupWebhook] ' + JSON.stringify(d));
    let confirmationSent = false;
    if (d.ok) {
      setBotCommands_();
      // 安裝完成直接推送平台選單；可同時驗證 bot、群組與 dashboard URL。
      confirmationSent = sendTelegramMenu(CFG.CHAT_ID);
      Logger.log('[setupWebhook] confirmation sent=' + confirmationSent);
    }
    return { ok:d.ok, description:d.description, webhookUrl:execUrl, confirmationSent:confirmationSent };
  } catch(err) { return { ok:false, error:err.toString() }; }
}

/** 把 /gc 放進 Telegram 指令清單，群組可直接點選，不必記指令。 */
function setBotCommands_() {
  try {
    const commands = [
      { command:'gc', description:'Open AC GASCHECK platform' },
      { command:'status', description:'Show cloud data status' },
      { command:'menu', description:'Show module menu' }
    ];
    const r = UrlFetchApp.fetch(TG_API() + '/setMyCommands', {
      method:'post', contentType:'application/json', muteHttpExceptions:true,
      payload:JSON.stringify({ commands:commands })
    });
    const d = JSON.parse(r.getContentText());
    Logger.log('[setMyCommands] ' + JSON.stringify(d));
    return d;
  } catch (err) {
    Logger.log('[setMyCommands ERROR] ' + err);
    return { ok:false, error:String(err) };
  }
}

/**
 * 一鍵修復 /gc：清除舊 webhook 狀態、重新註冊目前 /exec、註冊指令，
 * 並直接把平台選單送到群組作為完成測試。
 */
function repairWebhook() {
  // Telegram 不跟隨 ContentService 的 302 轉址；修復時清掉因舊回應累積的 update。
  const removed = deleteWebhook(true);
  clearUidCache();
  const commands = setBotCommands_();
  const webhook = setupWebhook(true);
  Utilities.sleep(800);
  const info = checkWebhook();
  const out = { removed:removed, commands:commands, webhook:webhook, info:info };
  Logger.log('[repairWebhook] ' + JSON.stringify(out));
  return out;
}

function checkWebhook() {
  const r = UrlFetchApp.fetch(TG_API() + '/getWebhookInfo', { muteHttpExceptions:true });
  const info = JSON.parse(r.getContentText());
  Logger.log('Expected URL: ' + (currentExecUrl_() || CFG.EXEC_URL || 'NOT SET'));
  Logger.log('URL: ' + ((info.result && info.result.url) || 'NOT SET'));
  Logger.log('Pending: ' + ((info.result && info.result.pending_update_count) || 0));
  Logger.log('LastErr: ' + ((info.result && info.result.last_error_message) || 'none'));
  return info;
}

function deleteWebhook(dropPending) {
  const r = UrlFetchApp.fetch(TG_API() + '/deleteWebhook', {
    method:'post', contentType:'application/json', muteHttpExceptions:true,
    payload: JSON.stringify({ drop_pending_updates:dropPending === true }),
  });
  return JSON.parse(r.getContentText());
}

function clearUidCache() {
  const props = PropertiesService.getScriptProperties();
  ['tg_processed_uids','tg_pending_update','tg_pending_uid'].forEach(function(k){ props.deleteProperty(k); });
  Logger.log('✅ UID cache cleared');
}

function resetAll() { return repairWebhook(); }

// ═══════════════════════════════════════════════════════════════
// SHEET HELPERS
// ═══════════════════════════════════════════════════════════════
function getOrCreateSheet_(name) {
  const ss = SpreadsheetApp.openById(CFG.SHEET_ID);
  let sheet = ss.getSheetByName(name);
  if (!sheet) { sheet = ss.insertSheet(name); Logger.log('[sheet] Created: ' + name); }
  return sheet;
}

function writeLog_(action, tool, count) {
  try {
    const sh = getOrCreateSheet_('Log');
    if (sh.getLastRow() === 0) { sh.appendRow(['ts','action','tool','count']); sh.setFrozenRows(1); }
    sh.appendRow([nowStr_(), action, tool, count]);
    if (sh.getLastRow() > 10001) sh.deleteRows(2, sh.getLastRow() - 10001);
  } catch(e) {}
}

const ACTIVITY_SHEET = 'ActivityLog';
const ACTIVITY_HEADERS = ['ts','event','tool','reportMonth','period','mode','scope','slot','language','ref','count','note'];

function ensureActivitySheet_() {
  const sh = getOrCreateSheet_(ACTIVITY_SHEET);
  ensureSheetHeaders_(sh, ACTIVITY_HEADERS);
  return sh;
}

function writeActivity_(entry) {
  try {
    entry = entry || {};
    const sh = ensureActivitySheet_();
    sh.appendRow(ACTIVITY_HEADERS.map(function(h) {
      return h === 'ts' ? nowStr_() : (entry[h] === undefined || entry[h] === null ? '' : entry[h]);
    }));
    if (sh.getLastRow() > 20001) sh.deleteRows(2, sh.getLastRow() - 20001);
    return true;
  } catch (e) {
    Logger.log('[ActivityLog] ' + e);
    return false;
  }
}

function normalizeMonthKey_(value) {
  if (value instanceof Date && !isNaN(value.getTime())) {
    return Utilities.formatDate(value, CFG.TZ, 'yyyy-MM');
  }
  const s = String(value === undefined || value === null ? '' : value).trim();
  let m = s.match(/(20\d{2})[-\/.](\d{1,2})(?:[-\/.]\d{1,2})?/);
  if (!m) m = s.match(/(20\d{2})\s*年\s*(\d{1,2})\s*月/);
  if (!m) return '';
  const month = Number(m[2]);
  return month >= 1 && month <= 12 ? m[1] + '-' + String(month).padStart(2, '0') : '';
}

function normalizeReportMode_(mode, text) {
  const m = String(mode || '').toLowerCase();
  if (m === 'summary' || m === 'approval' || m === 'review') return m;
  const s = String(text || '').toLowerCase();
  if (/approval|核可|អនុម័ត/.test(s)) return 'approval';
  if (/summary|摘要|សង្ខេប/.test(s)) return 'summary';
  if (/review|審查|ពិនិត្យ/.test(s)) return 'review';
  return 'message';
}

function recordBusinessMonths_(tool, records) {
  const fields = {
    asset:['purchase_date','date'], dormitory:['date'], cleaning:['date'],
    keymovement:['issue_date','datetime','return_date','date'], ehs:['date'],
    waterdrum:['date'], temperature:['d','date','ts']
  }[tool] || ['date'];
  const found = {};
  (records || []).forEach(function(rec) {
    if (!rec) return;
    let month = '';
    fields.some(function(field) {
      month = normalizeMonthKey_(rec[field]);
      return !!month;
    });
    if (!month && tool === 'waterdrum' && rec.year && rec.month) {
      month = normalizeMonthKey_(String(rec.year) + '-' + String(rec.month));
    }
    if (month) found[month] = true;
  });
  return Object.keys(found).sort();
}

function recordCloudUploadActivity_(payload, tool, records) {
  if (!Array.isArray(records) || !records.length) return;
  const months = {};
  const explicit = normalizeMonthKey_(payload.reportMonth || payload.reportRef || '');
  const businessMonths = recordBusinessMonths_(tool, records);
  businessMonths.forEach(function(m) { months[m] = true; });
  // Asset／Dormitory 可上傳「當月狀態快照」，資料本身不一定有當月交易日期；
  // 其餘交易型模組必須真的包含該月份記錄，避免只切換月份就被誤判為已上傳。
  if (explicit && (businessMonths.indexOf(explicit) >= 0 || tool === 'asset' || tool === 'dormitory')) {
    months[explicit] = true;
  }
  Object.keys(months).forEach(function(month) {
    writeActivity_({
      event:'cloud_upload', tool:tool, reportMonth:month,
      period:String(payload.reportPeriod || ''), mode:'',
      scope:String(payload.reportScope || ''), slot:String(payload.reportSlot || ''),
      language:String(payload.reportLanguage || ''), ref:String(payload.reportRef || ''),
      count:records.length, note:String(payload.mode || 'merge')
    });
  });
}

function readActivity_() {
  try { return sheetToJson_(ensureActivitySheet_()); }
  catch (e) { Logger.log('[readActivity] ' + e); return []; }
}

function nowStr_() {
  return Utilities.formatDate(new Date(), CFG.TZ, 'yyyy-MM-dd HH:mm:ss');
}

// ═══════════════════════════════════════════════════════════════
// INIT & REPORT
// ═══════════════════════════════════════════════════════════════
const SHEET_HDRS = {
  asset:       ['id','code','name','category','zone','status','quantity','unit','location','purchase_date','notes','photos','submitted_by','updatedAt'],
  dormitory:   ['id','type','name','gender','idNo','department','roomNo','date','reason','status','photos','updatedAt'],
  cleaning:    ['id','date','locId','shift','slots','checks','cleaner','checker','observer','note','photos','photoCount','status','updatedAt'],
  keymovement: ['id','key_code','key_name','key_no','dept','holder','recipient_name','checker','action','datetime','issue_date','issue_time','location','purpose','returned','return_date','return_condition','notes','remarks','photos','submitted_by','updatedAt'],
  ehs:         ['id','module','sourceType','date','plastic_kg','fabric_kg','core_kg','total_kg','name','supplier','car_number','solid_waste','industrial_waste','weight_kg','time_in','time_out','duration_min','gate_keeper','checked_by','anomaly','remark','photos','updatedAt'],
  waterdrum:   ['id','date','year','month','day','zone','name','reading_start','reading_end','consumption','qty','unitPrice','amount','fTime','sTime','checkBy','notes','photos','updatedAt'],
  temperature: ['id','d','date','time','ts','z','zone','t','temperature','h','humidity','wx','weather','checker','status','note','notes','photos','updatedAt'],
};

const MONTHLY_REPORT_MODULES = [
  {tool:'asset',       icon:'📦', zh:'資產',           en:'Asset',                  km:'ទ្រព្យសម្បត្តិ'},
  {tool:'dormitory',   icon:'🏠', zh:'宿舍',           en:'Dormitory',              km:'អន្តេវាសិកដ្ឋាន'},
  {tool:'cleaning',    icon:'🧹', zh:'清潔',           en:'Cleaning',               km:'ការសម្អាត'},
  {tool:'keymovement', icon:'🔑', zh:'鑰匙管理',       en:'Key Management',         km:'ការគ្រប់គ្រងសោ'},
  {tool:'ehs', scope:'recycle', icon:'♻️', zh:'EHS 回收', en:'EHS Recycle', km:'EHS ការកែច្នៃ'},
  {tool:'ehs', scope:'waste',   icon:'🗑️', zh:'EHS 廢棄物', en:'EHS Waste', km:'EHS សំណល់'},
  {tool:'waterdrum',   icon:'💧', zh:'飲用水',         en:'Drinking Water',         km:'ទឹកផឹក'},
  {tool:'temperature', icon:'🌡️', zh:'溫濕度',         en:'Temperature / Humidity', km:'សីតុណ្ហភាព / សំណើម'}
];

function previousMonthKey_(now) {
  now = now || new Date();
  let year = Number(Utilities.formatDate(now, CFG.TZ, 'yyyy'));
  let month = Number(Utilities.formatDate(now, CFG.TZ, 'M')) - 1;
  if (month < 1) { month = 12; year--; }
  return year + '-' + String(month).padStart(2, '0');
}

function moduleHasMonthData_(tool, reportMonth, scope) {
  try {
    const sh = getOrCreateSheet_(tool);
    let records = sheetToJson_(sh);
    if (tool === 'ehs' && scope) {
      records = records.filter(function(rec) {
        const type = String(rec.sourceType || (rec.module === 'gate' ? 'waste' : 'recycle')).toLowerCase();
        return type === scope;
      });
    }
    return recordBusinessMonths_(tool, records).indexOf(reportMonth) >= 0;
  } catch (e) {
    Logger.log('[moduleHasMonthData ' + tool + '] ' + e);
    return false;
  }
}

function auditMonthlyCompletion_(reportMonth) {
  reportMonth = normalizeMonthKey_(reportMonth);
  if (!reportMonth) throw new Error('Invalid report month');
  const activity = readActivity_().filter(function(row) {
    return normalizeMonthKey_(row.reportMonth) === reportMonth;
  });
  const modules = MONTHLY_REPORT_MODULES.map(function(mod) {
    const rows = activity.filter(function(row) { return String(row.tool || '') === mod.tool; });
    const cloudActivity = mod.tool === 'ehs' ? false : rows.some(function(row) {
      return String(row.event || '') === 'cloud_upload';
    });
    const cloud = cloudActivity || moduleHasMonthData_(mod.tool, reportMonth, mod.scope || '');
    const telegram = rows.some(function(row) {
      const mode = normalizeReportMode_(row.mode, '');
      const period = String(row.period || '').toLowerCase();
      const scope = String(row.scope || '').toLowerCase();
      const scopeMatch = !mod.scope || scope === 'all' || scope === mod.scope;
      return String(row.event || '') === 'telegram' &&
        (mode === 'summary' || mode === 'approval') && period === 'month' && scopeMatch;
    });
    return Object.assign({}, mod, {cloud:cloud, telegram:telegram, complete:cloud && telegram});
  });
  return {
    ok:true, reportMonth:reportMonth, modules:modules,
    missing:modules.filter(function(x) { return !x.complete; })
  };
}

function buildMonthlyMissingMessage_(audit) {
  const lines = [
    '⚠️ <b>上月報告缺件提醒 / Previous-month report reminder / ការរំលឹករបាយការណ៍ខែមុន</b>',
    '📅 ' + audit.reportMonth,
    '━━━━━━━━━━━━━━━━'
  ];
  audit.missing.forEach(function(item) {
    lines.push(item.icon + ' <b>' + item.zh + ' / ' + item.en + ' / ' + item.km + '</b>');
    if (!item.cloud) lines.push('  ❌ 未上傳雲端 / Cloud upload missing / មិនទាន់ផ្ទុកឡើង Cloud');
    else             lines.push('  ✅ 已上傳雲端 / Cloud uploaded / បានផ្ទុកឡើង Cloud');
    if (!item.telegram) lines.push('  ❌ 未發月摘要或核可 / Monthly summary or approval not sent / មិនទាន់ផ្ញើសេចក្តីសង្ខេបប្រចាំខែ ឬការអនុម័ត');
    else                lines.push('  ✅ 已發月摘要或核可 / Monthly summary or approval sent / បានផ្ញើសេចក្តីសង្ខេបប្រចាំខែ ឬការអនុម័ត');
  });
  lines.push(
    '━━━━━━━━━━━━━━━━',
    '請完成以上缺件；同一月份只提醒一次。',
    'Please complete the missing items above. This reminder is sent once per month.',
    'សូមបំពេញចំណុចដែលខ្វះខាងលើ។ ការរំលឹកនេះផ្ញើតែម្តងក្នុងមួយខែ។',
    '⏰ ' + nowStr_()
  );
  return lines.join('\n');
}

function sendMonthlyMissingReport_(reportMonth, markDone) {
  const audit = auditMonthlyCompletion_(reportMonth);
  const key = 'GASCHECK_MONTHLY_AUDIT_DONE_' + audit.reportMonth;
  const props = PropertiesService.getScriptProperties();
  if (markDone !== false && props.getProperty(key)) {
    return {ok:true, skipped:true, reason:'already_done', reportMonth:audit.reportMonth};
  }
  let sent = false;
  if (audit.missing.length) {
    const dashboard = {inline_keyboard:[[
      {text:'📊 Open Dashboard / 開啟平台 / បើកផ្ទាំងគ្រប់គ្រង', url:CFG.BASE_URL + 'ac_gascheck_portal_v1.html'}
    ]]};
    sent = tgSendWithKeyboard_(CFG.CHAT_ID, buildMonthlyMissingMessage_(audit), dashboard);
    if (!sent) return {ok:false, sent:false, reportMonth:audit.reportMonth, missing:audit.missing};
  }
  if (markDone !== false) {
    props.setProperty(key, JSON.stringify({ts:nowStr_(), sent:sent, missing:audit.missing.length}));
  }
  return {ok:true, sent:sent, reportMonth:audit.reportMonth, missing:audit.missing, modules:audit.modules};
}

/**
 * 每日觸發器入口：柬埔寨時間每月 5 日起檢查；若第 5 日傳送暫時失敗，
 * 後續日會重試，成功或確認無缺件後即鎖定該月份，不重複通知。
 */
function monthlyMissingReportReminder() {
  const day = Number(Utilities.formatDate(new Date(), CFG.TZ, 'd'));
  if (day < 5) return {ok:true, skipped:true, reason:'before_day_5'};
  const target = previousMonthKey_(new Date());
  const trackingStart = PropertiesService.getScriptProperties().getProperty('GASCHECK_MONTHLY_TRACKING_START') || '';
  if (trackingStart && target < trackingStart) {
    return {ok:true, skipped:true, reason:'before_tracking_start', reportMonth:target, trackingStart:trackingStart};
  }
  return sendMonthlyMissingReport_(target, true);
}

function previewMonthlyMissingReport() {
  const audit = auditMonthlyCompletion_(previousMonthKey_(new Date()));
  Logger.log(buildMonthlyMissingMessage_(audit));
  Logger.log(JSON.stringify(audit));
  return audit;
}

/** 手動測試：立即發送一次預覽，但不寫入「本月已提醒」鎖定。 */
function testMonthlyMissingReportReminder() {
  return sendMonthlyMissingReport_(previousMonthKey_(new Date()), false);
}

function setupMonthlyReminderTrigger() {
  const props = PropertiesService.getScriptProperties();
  if (!props.getProperty('GASCHECK_MONTHLY_TRACKING_START')) {
    props.setProperty('GASCHECK_MONTHLY_TRACKING_START', Utilities.formatDate(new Date(), CFG.TZ, 'yyyy-MM'));
  }
  ScriptApp.getProjectTriggers().forEach(function(t) {
    if (t.getHandlerFunction() === 'monthlyMissingReportReminder') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('monthlyMissingReportReminder').timeBased().everyDays(1).atHour(9).create();
  Logger.log('✅ monthlyMissingReportReminder trigger set (daily check; sends once from day 5, PNH)');
  return {ok:true, handler:'monthlyMissingReportReminder', schedule:'daily after 09:00; active from day 5 Asia/Phnom_Penh'};
}

function ensureSheetHeaders_(sh, wanted) {
  if (!wanted || !wanted.length) return [];
  if (sh.getLastRow() === 0 || sh.getLastColumn() === 0) {
    sh.getRange(1,1,1,wanted.length).setValues([wanted])
      .setBackground('#1A3458').setFontColor('#fff').setFontWeight('bold');
    sh.setFrozenRows(1);
    return wanted.slice();
  }
  const current = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0]
    .map(function(x){ return String(x || '').trim(); }).filter(Boolean);
  const missing = wanted.filter(function(h){ return current.indexOf(h) < 0; });
  if (missing.length) {
    sh.getRange(1, current.length + 1, 1, missing.length).setValues([missing])
      .setBackground('#1A3458').setFontColor('#fff').setFontWeight('bold');
  }
  sh.setFrozenRows(1);
  return current.concat(missing);
}

function initSheets() {
  const result = {};
  CFG.MODULES.forEach(function(mod) {
    const sh = getOrCreateSheet_(mod);
    result[mod] = ensureSheetHeaders_(sh, SHEET_HDRS[mod]);
  });
  getOrCreateSheet_('Log');
  ensureActivitySheet_();
  Logger.log('✅ initSheets complete');
  return { ok:true, modules:result };
}

/**
 * 唯一需要手動執行的安裝函式。可重複執行：
 * - 工作表不存在才建立；既有資料不清除
 * - 只補缺少欄位
 * - 修復 webhook、/gc 指令並送出平台選單測試
 */
function installGascheck() {
  const sheets = initSheets();
  const monthlyReminder = setupMonthlyReminderTrigger();
  const telegram = repairWebhook();
  // webhook 註冊成功但群組收不到選單，也要明確回報失敗，避免看似安裝成功而 /gc 仍無反應。
  const result = {
    ok:!!(telegram.webhook && telegram.webhook.ok && telegram.webhook.confirmationSent),
    version:CFG.CORE_VERSION,
    sheets:sheets,
    monthlyReminder:monthlyReminder,
    telegram:telegram
  };
  Logger.log('[installGascheck] ' + JSON.stringify(result));
  return result;
}

function weeklyReport() {
  try {
    const s     = handleStatus_();
    const icons = {asset:'📦',dormitory:'🏠',cleaning:'🧹',keymovement:'🔑',ehs:'♻️',waterdrum:'💧',temperature:'🌡️'};
    const lines = ['📊 <b>AC GASCHECK 週報</b>',
                   '📅 ' + Utilities.formatDate(new Date(), CFG.TZ, 'yyyy/MM/dd'),
                   '━━━━━━━━━━━━━━━━'];
    Object.keys(s.modules).forEach(function(m) {
      lines.push((icons[m]||'📋') + ' ' + m + ': ' + s.modules[m] + ' 筆');
    });
    lines.push('━━━━━━━━━━━━━━━━','🏭 Vantage River Textiles · SHV');
    tgSendText_(CFG.CHAT_ID, lines.join('\n'));
  } catch(err) { Logger.log('[weeklyReport ERR] ' + err); }
}

function setupWeeklyTrigger() {
  ScriptApp.getProjectTriggers().forEach(function(t){
    if (t.getHandlerFunction() === 'weeklyReport') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('weeklyReport').timeBased().onWeekDay(ScriptApp.WeekDay.MONDAY).atHour(9).create();
  Logger.log('✅ weeklyReport trigger set (Mon 09:00 PNH)');
}

// ═══════════════════════════════════════════════════════════════
// RESPONSE
// ═══════════════════════════════════════════════════════════════
function okResp(data) {
  const out = (data && typeof data === 'object') ? data : { data: data };
  if (out.ok === undefined) out.ok = true;
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

/**
 * Telegram webhook 必須直接收到 HTTP 200，且 Telegram 不支援 3xx 轉址。
 * Apps Script ContentService 會轉到 script.googleusercontent.com，所以 Telegram update
 * 專用 HtmlService 回應；前端資料 API 仍保留 JSON ContentService。
 */
function telegramResp_(data) {
  const out = (data && typeof data === 'object') ? data : { data:data };
  if (out.ok === undefined) out.ok = true;
  return HtmlService.createHtmlOutput(JSON.stringify(out));
}

function failResp(error) {
  return ContentService.createTextOutput(JSON.stringify({ ok:false, error:error })).setMimeType(ContentService.MimeType.JSON);
}

// ═══════════════════════════════════════════════════════════════
// TESTS
// ═══════════════════════════════════════════════════════════════
function testInit()         { initSheets(); }
function testStatus()       { Logger.log(JSON.stringify(handleStatus_())); }
function testTg()           { tgSendText_(CFG.CHAT_ID, '✅ AC_GASCHECK_CORE ' + CFG.CORE_VERSION + ' 測試成功'); }
function testMenu()         { sendTelegramMenu(CFG.CHAT_ID); }
function testCheckWebhook() { checkWebhook(); }
function testGcHandler()    { handleTelegram({ update_id:Date.now(), message:{ chat:{id:CFG.CHAT_ID}, text:'/gc' } }); }

/** ★ 關鍵測試：驗證「推少量資料不會蓋掉既有」 */
function testMergeSafety() {
  const T = 'temperature';
  const sh = getOrCreateSheet_(T);
  const before = sheetToJson_(sh);
  Logger.log('測試前 Sheet 筆數: ' + before.length);

  if (before.length === 0) {
    Logger.log('⚠ Sheet 無資料，先推 3 筆測試資料');
    handlePush_({ tool:T, records:[
      {id:'T1',date:'2026-01-01',zone:'A',temperature:28,updatedAt:'2026-01-01 08:00:00'},
      {id:'T2',date:'2026-01-02',zone:'B',temperature:29,updatedAt:'2026-01-02 08:00:00'},
      {id:'T3',date:'2026-01-03',zone:'C',temperature:30,updatedAt:'2026-01-03 08:00:00'},
    ]});
  }

  const mid = sheetToJson_(sh).length;
  Logger.log('推送前筆數: ' + mid);

  // 只推 1 筆且時間戳較舊
  const r = handlePush_({ tool:T, records:[
    {id:'T1',date:'2020-01-01',zone:'OLD',temperature:1,updatedAt:'2020-01-01 00:00:00'}
  ]});

  const after = sheetToJson_(sh).length;
  Logger.log('推送後筆數: ' + after);
  Logger.log('結果: ' + JSON.stringify(r));

  if (after >= mid) Logger.log('✅ 通過 — 既有資料未被覆蓋');
  else              Logger.log('❌ 失敗 — 資料減少了！' + mid + ' → ' + after);
}
